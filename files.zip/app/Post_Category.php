<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post_Category extends Model
{


  protected $table='post_categories';

  protected $fillable = ['post_category_id', 'category_description'];





















}
