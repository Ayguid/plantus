<?php

namespace App\Traits;

use App\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Post;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as ImageTools;




trait ImageHelper
{


  public function saveImages($request, $who, $form_key, $where)
  {
    foreach ($request->file($form_key) as $key => $image)
    {
      $filename    = md5(uniqid() . time()) . '.' . $image->getClientOriginalExtension();
      $newImage= new Image();
      $newImage->image_path=$filename;
      $newImage->user_id=Auth::user()->id;

        if ($image->getClientOriginalExtension() == 'gif') {
          $who->images()->save($newImage);
          $image->storeAs('public/'.$where, $filename);
          $status = true;
        }
        else {
          $img = ImageTools::make($image->getRealPath());
          $img->resize(1080, 1080);
          if ($who->images()->save($newImage) && $img->save(public_path('storage/' .$where.'/'. $filename)))
          {
            $status = true;
          }else
          {
            $status = false;
          }
        }
    }
    return $status;
  }



  public function destroyImages($who, $where)
  {
    foreach ($who->images as $image)
    {
      if (Storage::delete('public/'.$where.$image->image_path))
      {
        $status = true;
      }else
      {
        $status = false;
      }
    }
    return $status;
  }









}
