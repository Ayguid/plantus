<?php

namespace App\Http\Controllers;


class FeedController extends Controller
{



  public function feedIndex()
  {
    return view('feed');
  }


















}
